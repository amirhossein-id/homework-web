﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            List<Users> ListUsers = new List<Users>();
            Users obj1 = new Users();
            obj1.Id = 1;
            obj1.Company = "Benz";
            obj1.Color = "Red";
            obj1.Password = "123456";
            obj1.Price = 3500;
            obj1.Year = DateTime.Parse("2000/01/01");
            obj1.Active = true;
            ListUsers.Add(obj1);

            Users obj = new Users();
            obj.Id = 2;
            obj.Company = "Bmw";
            obj.Color = "blue";
            obj.Password = "123456";
            obj.Price = 2500;
            obj.Year = DateTime.Parse("2000/01/01");
            obj.Active = true;
            ListUsers.Add(obj);


            var query = ListUsers.ToList();
            double SumAllprice = 0;
            foreach (var item in query)
            {
                SumAllprice += item.Price.Value;
            }
            View.ret = SumAllprice;
            return View(query);
        }

        public IActionResult Error()
        {
            return View("~/Views/Shared/Error.cshtml");
        }
    }
}
