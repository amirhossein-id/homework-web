﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace WebApplication4.Models
{
    public class Users
    {
        [Required]
        [Key]
        public int Id { get; set;}
        [StringLength(100)]
        public string Color { get; set; }
        [StringLength(100)]
        public string Company { get; set; }
        [StringLength(100)]
        public string Password { get; set; }
        public DateTime Year { get; set; }
        public double? Price { get; set; }
        public bool? Active { get; set; }
    }
}
