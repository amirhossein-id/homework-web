﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
//using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;

public partial class sendcomment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "" && TextBox2.Text != ""  && TextBox4.Text != "" && TextBox5.Text != "")
        {
            if (TextBox2.Text == TextBox4.Text)
            {
                database db = new database();
                db.run("insert into login(username,password,email) values(N'" + TextBox1.Text + "',N'" + TextBox2.Text + "',N'" + TextBox5.Text + "')");
                Label1.Text = "اطلاعات  شما ثبت شد";
            }
            else
                Label1.Text = "رمز عبور و تکرار آن مطابقت ندارند";
        }
        else
        {
            Label1.Text = "اطلاعات را کامل و صحیح وارد کنید";
        }
    }
}
