﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
//using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;

public partial class sendcomment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        database db = new database();
        dt = db.get("select * from login where username=N'"+TextBox1.Text+"' and password=N'"+TextBox2.Text+"'");
        if (dt.Rows.Count>0)
        {
            Response.Redirect("index.aspx?user="+TextBox1.Text);
        }
        else
        {
            Label1.Text = "رمز عبور یا نام کاربری اشتباه است";
        }
    }
}
